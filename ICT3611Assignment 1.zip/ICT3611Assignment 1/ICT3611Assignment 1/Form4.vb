﻿Imports System.IO
Public Class Form4

    'Private mywriter As New StreamWriter

    Private Sub RichTextBox1_TextChanged(sender As Object, e As EventArgs)

    End Sub

    Private Sub BtnMain_Click(sender As Object, e As EventArgs) Handles BtnMain.Click
        ' code to link the main page
        Me.Hide()
        Form1.Visible = True
    End Sub

    Private Sub BtnEvent_Click(sender As Object, e As EventArgs) Handles BtnEvent.Click
        ' code to link the events page
        Me.Hide()
        Form2.Visible = True
    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        ' code to link the events page
        Me.Hide()
        Form3.Visible = True
    End Sub

    Private Sub BtnExit_Click(sender As Object, e As EventArgs) Handles BtnExit.Click
        Dim messager As String = "Are you sure you want to Exit " & "?"
        Dim button As DialogResult = MessageBox.Show(messager,
            "Confirm Delete", MessageBoxButtons.YesNo)
        If button = DialogResult.Yes Then
            Me.Close()
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If OpenFileDialog1.ShowDialog() = DialogResult.OK Then
            Dim lines = File.ReadAllLines(OpenFileDialog1.FileName)
            ListBox2.Items.Clear()
            ListBox2.Items.AddRange(lines)
        End If

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim savefile(5) As String
        savefile(0) = TextBoxSear.Text & " , " & driverNam.Text & " , " & evnt.Text & " , " & postion.Text
        SaveFileDialog1.Filter = "TXT Files(*.txt*)|*.txt"
        If SaveFileDialog1.ShowDialog() = DialogResult.OK Then
            Using Writer = New StreamWriter(SaveFileDialog1.FileName)
                For Each info As Object In ListBox1.Items
                    Writer.WriteLine(info)
                Next
            End Using
        End If
    End Sub

    Private Sub Regst_Click(sender As Object, e As EventArgs) Handles Regst.Click
        Dim savefile As String
        savefile = TextBoxSear.Text & " , " & driverNam.Text & " , " & evnt.Text & " , " & postion.Text
        ListBox1.Items.Add(savefile)
    End Sub

    Private Sub Form4_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class