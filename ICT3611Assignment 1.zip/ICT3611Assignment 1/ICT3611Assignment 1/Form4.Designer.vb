﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form4
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.postion = New System.Windows.Forms.TextBox()
        Me.evnt = New System.Windows.Forms.TextBox()
        Me.driverNam = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Drivr = New System.Windows.Forms.Label()
        Me.TextBoxSear = New System.Windows.Forms.TextBox()
        Me.IdSearch = New System.Windows.Forms.Label()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.Regst = New System.Windows.Forms.Button()
        Me.BtnExit = New System.Windows.Forms.Button()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.BtnEvent = New System.Windows.Forms.Button()
        Me.BtnMain = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.ListBox1 = New System.Windows.Forms.ListBox()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.ListBox2 = New System.Windows.Forms.ListBox()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'postion
        '
        Me.postion.Location = New System.Drawing.Point(140, 427)
        Me.postion.Name = "postion"
        Me.postion.Size = New System.Drawing.Size(100, 20)
        Me.postion.TabIndex = 26
        '
        'evnt
        '
        Me.evnt.Location = New System.Drawing.Point(140, 395)
        Me.evnt.Name = "evnt"
        Me.evnt.Size = New System.Drawing.Size(100, 20)
        Me.evnt.TabIndex = 25
        '
        'driverNam
        '
        Me.driverNam.Location = New System.Drawing.Point(140, 358)
        Me.driverNam.Name = "driverNam"
        Me.driverNam.Size = New System.Drawing.Size(100, 20)
        Me.driverNam.TabIndex = 24
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(6, 430)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(116, 13)
        Me.Label4.TabIndex = 23
        Me.Label4.Text = "POSITION OBTAINED"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(6, 395)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(80, 13)
        Me.Label3.TabIndex = 22
        Me.Label3.Text = "EVENT_NAME"
        '
        'Drivr
        '
        Me.Drivr.AutoSize = True
        Me.Drivr.Location = New System.Drawing.Point(3, 358)
        Me.Drivr.Name = "Drivr"
        Me.Drivr.Size = New System.Drawing.Size(85, 13)
        Me.Drivr.TabIndex = 21
        Me.Drivr.Text = "DRIVER_NAME"
        '
        'TextBoxSear
        '
        Me.TextBoxSear.Location = New System.Drawing.Point(140, 321)
        Me.TextBoxSear.Name = "TextBoxSear"
        Me.TextBoxSear.Size = New System.Drawing.Size(160, 20)
        Me.TextBoxSear.TabIndex = 20
        '
        'IdSearch
        '
        Me.IdSearch.AutoSize = True
        Me.IdSearch.Location = New System.Drawing.Point(0, 321)
        Me.IdSearch.Name = "IdSearch"
        Me.IdSearch.Size = New System.Drawing.Size(118, 13)
        Me.IdSearch.TabIndex = 19
        Me.IdSearch.Text = "SEARCH MEMBER_ID"
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.ICT3611Assignment_1.My.Resources.Resources.resu
        Me.PictureBox1.Location = New System.Drawing.Point(3, -1)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(389, 283)
        Me.PictureBox1.TabIndex = 27
        Me.PictureBox1.TabStop = False
        '
        'Regst
        '
        Me.Regst.BackColor = System.Drawing.Color.SandyBrown
        Me.Regst.Location = New System.Drawing.Point(352, 476)
        Me.Regst.Name = "Regst"
        Me.Regst.Size = New System.Drawing.Size(101, 45)
        Me.Regst.TabIndex = 32
        Me.Regst.Text = "Save To ListBox"
        Me.Regst.UseVisualStyleBackColor = False
        '
        'BtnExit
        '
        Me.BtnExit.BackColor = System.Drawing.Color.SandyBrown
        Me.BtnExit.Location = New System.Drawing.Point(540, 476)
        Me.BtnExit.Name = "BtnExit"
        Me.BtnExit.Size = New System.Drawing.Size(75, 45)
        Me.BtnExit.TabIndex = 31
        Me.BtnExit.Text = "Exit"
        Me.BtnExit.UseVisualStyleBackColor = False
        '
        'Button3
        '
        Me.Button3.BackColor = System.Drawing.Color.SandyBrown
        Me.Button3.Location = New System.Drawing.Point(166, 476)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(75, 45)
        Me.Button3.TabIndex = 30
        Me.Button3.Text = "Registration"
        Me.Button3.UseVisualStyleBackColor = False
        '
        'BtnEvent
        '
        Me.BtnEvent.BackColor = System.Drawing.Color.SandyBrown
        Me.BtnEvent.Location = New System.Drawing.Point(85, 476)
        Me.BtnEvent.Name = "BtnEvent"
        Me.BtnEvent.Size = New System.Drawing.Size(75, 45)
        Me.BtnEvent.TabIndex = 29
        Me.BtnEvent.Text = "Next Event"
        Me.BtnEvent.UseVisualStyleBackColor = False
        '
        'BtnMain
        '
        Me.BtnMain.BackColor = System.Drawing.Color.SandyBrown
        Me.BtnMain.Location = New System.Drawing.Point(4, 476)
        Me.BtnMain.Name = "BtnMain"
        Me.BtnMain.Size = New System.Drawing.Size(75, 45)
        Me.BtnMain.TabIndex = 28
        Me.BtnMain.Text = "Main"
        Me.BtnMain.UseVisualStyleBackColor = False
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.Color.SandyBrown
        Me.Button1.Location = New System.Drawing.Point(459, 456)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 65)
        Me.Button1.TabIndex = 33
        Me.Button1.Text = "Load Previous info"
        Me.Button1.UseVisualStyleBackColor = False
        '
        'ListBox1
        '
        Me.ListBox1.FormattingEnabled = True
        Me.ListBox1.Location = New System.Drawing.Point(398, 12)
        Me.ListBox1.Name = "ListBox1"
        Me.ListBox1.Size = New System.Drawing.Size(301, 264)
        Me.ListBox1.TabIndex = 34
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.SandyBrown
        Me.Button2.Location = New System.Drawing.Point(247, 476)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(101, 45)
        Me.Button2.TabIndex = 35
        Me.Button2.Text = "Save "
        Me.Button2.UseVisualStyleBackColor = False
        '
        'ListBox2
        '
        Me.ListBox2.FormattingEnabled = True
        Me.ListBox2.Location = New System.Drawing.Point(388, 294)
        Me.ListBox2.Name = "ListBox2"
        Me.ListBox2.Size = New System.Drawing.Size(311, 147)
        Me.ListBox2.TabIndex = 36
        '
        'Form4
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(711, 526)
        Me.Controls.Add(Me.ListBox2)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.ListBox1)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Regst)
        Me.Controls.Add(Me.BtnExit)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(Me.BtnEvent)
        Me.Controls.Add(Me.BtnMain)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.postion)
        Me.Controls.Add(Me.evnt)
        Me.Controls.Add(Me.driverNam)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Drivr)
        Me.Controls.Add(Me.TextBoxSear)
        Me.Controls.Add(Me.IdSearch)
        Me.Name = "Form4"
        Me.Text = "Form4"
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents postion As System.Windows.Forms.TextBox
    Friend WithEvents evnt As System.Windows.Forms.TextBox
    Friend WithEvents driverNam As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Drivr As System.Windows.Forms.Label
    Friend WithEvents TextBoxSear As System.Windows.Forms.TextBox
    Friend WithEvents IdSearch As System.Windows.Forms.Label
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents Regst As System.Windows.Forms.Button
    Friend WithEvents BtnExit As System.Windows.Forms.Button
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents BtnEvent As System.Windows.Forms.Button
    Friend WithEvents BtnMain As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents ListBox1 As System.Windows.Forms.ListBox
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents SaveFileDialog1 As System.Windows.Forms.SaveFileDialog
    Friend WithEvents ListBox2 As System.Windows.Forms.ListBox
End Class
