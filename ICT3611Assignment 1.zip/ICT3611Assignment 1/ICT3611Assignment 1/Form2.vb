﻿Public Class Form2

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        ' code to link the events page
        Me.Hide()
        Form1.Visible = True
    End Sub

    Private Sub BtnReg_Click(sender As Object, e As EventArgs) Handles BtnReg.Click
        ' code to link the Registration page
        Me.Hide()
        Form3.Visible = True
    End Sub

    Private Sub BtnRes_Click(sender As Object, e As EventArgs) Handles BtnRes.Click
        ' code to link the results page
        Me.Hide()
        Form4.Visible = True
    End Sub

    Private Sub BtnExit_Click(sender As Object, e As EventArgs) Handles BtnExit.Click
        Dim messager As String = "Are you sure you want to Exit " & "?"
        Dim button As DialogResult = MessageBox.Show(messager,
            "Confirm Delete", MessageBoxButtons.YesNo)
        If button = DialogResult.Yes Then
            Me.Close()
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click


        'Dim savefile(5) As String

        'savefile(0) = ComboBox1.Text & " , " & DateTimePicker1.Text & " , " & TextBox2.Text & " , " & ComboBox2.Text & " , " & ComboBox3.Text
        Dim iSave As New SaveFileDialog
        iSave.Filter = "txt files(*.txt) |*.txt"
        iSave.FilterIndex = 2
        iSave.RestoreDirectory = False

        If iSave.ShowDialog() = DialogResult.OK Then
            IO.File.WriteAllText(iSave.FileName, ComboBox1.Text & " , " & DateTimePicker1.Text & " , " & TextBox2.Text & " , " & ComboBox2.Text & " , " & ComboBox3.Text)

        End If




                MessageBox.Show("You are about to save", "Cautions!!!!", MessageBoxButtons.OK, MessageBoxIcon.Question)



    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim savefile As String
        savefile = ComboBox1.Text & " , " & DateTimePicker1.Text & " , " & TextBox2.Text & " , " & ComboBox2.Text & " , " & ComboBox3.Text
        ListBox1.Items.Add(savefile)
    End Sub

    Private Sub MenuStrip1_ItemClicked(sender As Object, e As ToolStripItemClickedEventArgs)

    End Sub

    Private Sub PictureBox2_Click(sender As Object, e As EventArgs) Handles PictureBox2.Click

    End Sub

   

    Private Sub SaveToolStripMenuItem_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub ExitToolStripMenuItem_Click_1(sender As Object, e As EventArgs) Handles ExitToolStripMenuItem.Click
        Dim messager As String = "Are you sure you want to Exit " & "?"
        Dim button As DialogResult = MessageBox.Show(messager,
            "Confirm Delete", MessageBoxButtons.YesNo)
        If button = DialogResult.Yes Then
            Me.Close()
        End If
    End Sub

    Private Sub SaveToolStripMenuItem1_Click(sender As Object, e As EventArgs) Handles SaveToolStripMenuItem1.Click

    End Sub

    Private Sub ContextMenuStrip1_Opening(sender As Object, e As System.ComponentModel.CancelEventArgs) Handles ContextMenuStrip1.Opening

    End Sub

    Private Sub ClearFielsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ClearFielsToolStripMenuItem.Click
        'clearing the form
        If MessageBox.Show("Do you really want to clear?", "Clear Fields", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
            With Me

                .ComboBox1.ResetText()
                .TextBox2.Clear()
                .DateTimePicker1.ResetText()
                .ComboBox2.ResetText()
                .ComboBox3.ResetText()



            End With
        End If
    End Sub
End Class