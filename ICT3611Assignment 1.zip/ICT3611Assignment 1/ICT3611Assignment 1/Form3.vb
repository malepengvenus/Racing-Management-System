﻿Public Class Form3


    Public number As Integer = 114545
    Public MemNumber As Integer
    Public c As Integer = number

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        ' code to link the main page
        Me.Hide()
        Form1.Visible = True
    End Sub

    Private Sub BtnReg_Click(sender As Object, e As EventArgs) Handles BtnReg.Click
        ' code to link the events page
        Me.Hide()
        Form2.Visible = True
    End Sub

    Private Sub BtnRes_Click(sender As Object, e As EventArgs) Handles BtnRes.Click
        ' code to link the results page
        Me.Hide()
        Form4.Visible = True
    End Sub

    Private Sub BtnExit_Click(sender As Object, e As EventArgs) Handles BtnExit.Click
        Dim messager As String = "Are you sure you want to Exit " & "?"
        Dim button As DialogResult = MessageBox.Show(messager,
            "Confirm Delete", MessageBoxButtons.YesNo)
        If button = DialogResult.Yes Then
            Me.Close()
        End If
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        'Generate Member NR using a while loop
        c += 1
        While (c > 9)
            MemNumber += (c Mod 15)
            c /= 10
        End While
        MemNumber = 19 - (MemNumber Mod 15)
        MemNumber = CInt(number.ToString & MemNumber.ToString)
        number += 1
        'outputting it on a message box and a label
        MsgBox("" & MemNumber)
        Me.labelMemNum.Text = "" & MemNumber

        MessageBox.Show("Memeber ship number has been generated", "press Ok", MessageBoxButtons.OK, MessageBoxIcon.Asterisk)

    End Sub

    Private Sub Button4_Click(sender As Object, e As EventArgs) Handles Button4.Click



        If TxtName.Text = "" Then
            MsgBox("Please Enter Your Name ")
        ElseIf TxtSurname.Text = "" Then
            MsgBox("Please Enter your Surname")
        ElseIf DateTimePicker1.Text = "" Then
            MsgBox("Please Enter your Born Date")
        ElseIf DateTimePicker2.Text = "" Then
            MsgBox("Enter your Joining Date ")
        ElseIf TxtOutFee.Text = "" Then
            MsgBox("Enter your outstanding Fee")
        ElseIf ComboBox3.Text = "" Then
            MsgBox("Enter your Position Achieved")

        ElseIf ComboBox2.Text = "" Then
            MsgBox("Please Enter Position You Achieved")
        Else
            Try
                Throw New Exception("Make Sure Membership Number Is Generated")
            Catch ex As Exception

                Dim iSave As New SaveFileDialog
                iSave.Filter = "txt files(*.txt) |*.txt"
                iSave.FilterIndex = 2
                iSave.RestoreDirectory = False

                If iSave.ShowDialog() = DialogResult.OK Then
                    IO.File.WriteAllText(iSave.FileName, TxtName.Text & " , " & TxtSurname.Text & " , " & DateTimePicker1.Text & " , " & ComboBox1.Text & " , " & DateTimePicker2.Text & " , " & TxtOutFee.Text & " , " & ComboBox3.Text & " , " & ComboBox2.Text & " , " & labelMemNum.Text)

                End If

                MsgBox("Race Driver Is Succesfully Registered")



                MessageBox.Show("You are about to save", "Cautions!!!!", MessageBoxButtons.OK, MessageBoxIcon.Question)
            End Try
        End If

    End Sub

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        Dim savefile As String
        savefile = TxtName.Text & " , " & TxtSurname.Text & " , " & DateTimePicker1.Text & " , " & ComboBox1.Text & " , " & DateTimePicker2.Text & " , " & TxtOutFee.Text & " , " & ComboBox3.Text & " , " & ComboBox2.Text & " , " & labelMemNum.Text
        ListBox1.Items.Add(savefile)
    End Sub

    Private Sub Button5_Click(sender As Object, e As EventArgs) Handles Button5.Click
        If MessageBox.Show("Do you really want to clear All your fields?", "Clear Fields", MessageBoxButtons.YesNo, MessageBoxIcon.Question) = Windows.Forms.DialogResult.Yes Then
            With Me
                ' code to clear the fields
                .TxtName.Clear()
                .TxtSurname.Clear()
                .TxtOutFee.Clear()
                DateTimePicker1.ResetText()
                DateTimePicker2.ResetText()
                ComboBox3.ResetText()

                .labelMemNum.Clear()




            End With
        End If
    End Sub
End Class